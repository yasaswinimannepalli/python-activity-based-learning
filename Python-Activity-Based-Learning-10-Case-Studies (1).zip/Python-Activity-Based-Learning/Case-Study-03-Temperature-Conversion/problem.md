# Case Study 3: Celsius to Fahrenheit Conversion

## Student Details
- **Name:** Mannepalli Yasaswini
- **Roll Number:** 26000946
- **Branch:** CSE, AIML
- **Section:** CSM2

## Problem Statement
Convert a temperature in Celsius to Fahrenheit.

## Objectives
Apply the formula F = (C × 9/5) + 32.

## Assumptions
The input is a valid numeric Celsius temperature.

## Algorithm
1. Start.
2. Read temperature C in Celsius.
3. Calculate F = (C * 9 / 5) + 32.
4. Display F.
5. Stop.

## Flowchart
```text
[START]
   |
[Read Celsius C]
   |
[F = (C × 9 / 5) + 32]
   |
[Display Fahrenheit F]
   |
 [STOP]
```

## Pseudocode
```text
BEGIN
  INPUT C
  F ← (C × 9 / 5) + 32
  PRINT F
END
```

## Python Source Code
```python
celsius = float(input("Enter temperature in Celsius: "))
fahrenheit = (celsius * 9 / 5) + 32
print("Temperature in Fahrenheit =", fahrenheit)
```

## Test Cases
Test 1: Input: 0
Expected output: 32.0 °F
Test 2: Input: 100
Expected output: 212.0 °F
Test 3: Input: -40
Expected output: -40.0 °F

## Sample Output
```text
Enter temperature in Celsius: 25
Temperature in Fahrenheit = 77.0
```

## Output Screenshot
Save a screenshot of the actual program output here after running `program.py`. The text output above is illustrative, not a screenshot.

## Conclusion
The program converts Celsius temperatures to Fahrenheit using a standard formula.
