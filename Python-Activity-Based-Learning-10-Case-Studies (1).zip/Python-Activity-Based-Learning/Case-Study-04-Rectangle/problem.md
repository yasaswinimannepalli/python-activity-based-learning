# Case Study 4: Area and Perimeter of a Rectangle

## Student Details
- **Name:** Mannepalli Yasaswini
- **Roll Number:** 26000946
- **Branch:** CSE, AIML
- **Section:** CSM2

## Problem Statement
Calculate the area and perimeter of a rectangle using its length and width.

## Objectives
Use arithmetic formulas and numeric input.

## Assumptions
Length and width are non-negative numeric values.

## Algorithm
1. Start.
2. Read length and width.
3. Calculate area = length × width.
4. Calculate perimeter = 2 × (length + width).
5. Display results and stop.

## Flowchart
```text
[START]
   |
[Read length and width]
   |
[area = length × width]
[perimeter = 2 × (length + width)]
   |
[Display area and perimeter]
   |
 [STOP]
```

## Pseudocode
```text
BEGIN
  INPUT length, width
  area ← length × width
  perimeter ← 2 × (length + width)
  PRINT area, perimeter
END
```

## Python Source Code
```python
length = float(input("Enter rectangle length: "))
width = float(input("Enter rectangle width: "))

area = length * width
perimeter = 2 * (length + width)

print("Area =", area)
print("Perimeter =", perimeter)
```

## Test Cases
Test 1: Input: 5, 3
Expected output: Area = 15.0; Perimeter = 16.0
Test 2: Input: 4, 4
Expected output: Area = 16.0; Perimeter = 16.0

## Sample Output
```text
Enter rectangle length: 5
Enter rectangle width: 3
Area = 15.0
Perimeter = 16.0
```

## Output Screenshot
Save a screenshot of the actual program output here after running `program.py`. The text output above is illustrative, not a screenshot.

## Conclusion
The program calculates a rectangle's area and perimeter from its dimensions.
