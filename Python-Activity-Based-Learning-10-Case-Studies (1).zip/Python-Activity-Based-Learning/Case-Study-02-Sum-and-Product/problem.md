# Case Study 2: Sum and Product of Two Numbers

## Student Details
- **Name:** Mannepalli Yasaswini
- **Roll Number:** 26000946
- **Branch:** CSE, AIML
- **Section:** CSM2

## Problem Statement
Write a Python program to calculate the sum and product of two numbers.

## Objectives
Use numeric variables and arithmetic operators.

## Assumptions
The user enters valid numeric values.

## Algorithm
1. Start.
2. Read two numbers a and b.
3. Calculate sum = a + b and product = a * b.
4. Display both results.
5. Stop.

## Flowchart
```text
[START]
   |
[Read a and b]
   |
[sum = a + b; product = a * b]
   |
[Display sum and product]
   |
 [STOP]
```

## Pseudocode
```text
BEGIN
  INPUT a, b
  sum ← a + b
  product ← a × b
  PRINT sum, product
END
```

## Python Source Code
```python
a = float(input("Enter first number: "))
b = float(input("Enter second number: "))

print("Sum =", a + b)
print("Product =", a * b)
```

## Test Cases
Test 1: Input: 4, 5
Expected output: Sum = 9.0; Product = 20.0
Test 2: Input: -2, 3
Expected output: Sum = 1.0; Product = -6.0

## Sample Output
```text
Enter first number: 4
Enter second number: 5
Sum = 9.0
Product = 20.0
```

## Output Screenshot
Save a screenshot of the actual program output here after running `program.py`. The text output above is illustrative, not a screenshot.

## Conclusion
The program applies addition and multiplication to two input values.
