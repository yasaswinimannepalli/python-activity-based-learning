# Case Study 7: Check Even or Odd

## Student Details
- **Name:** Mannepalli Yasaswini
- **Roll Number:** 26000946
- **Branch:** CSE, AIML
- **Section:** CSM2

## Problem Statement
Determine whether an integer is even or odd.

## Objectives
Use the modulus operator and a conditional statement.

## Assumptions
The user enters an integer.

## Algorithm
1. Start.
2. Read integer n.
3. If n % 2 == 0, display Even.
4. Otherwise display Odd.
5. Stop.

## Flowchart
```text
[START]
   |
[Read integer n]
   |
[n % 2 == 0?]
  /        \
Yes        No
 |          |
[Even]     [Odd]
  \        /
    [STOP]
```

## Pseudocode
```text
BEGIN
  INPUT n
  IF n MOD 2 = 0 THEN PRINT Even
  ELSE PRINT Odd
END
```

## Python Source Code
```python
n = int(input("Enter an integer: "))

if n % 2 == 0:
    print(n, "is even")
else:
    print(n, "is odd")
```

## Test Cases
Test 1: Input: 8
Expected output: 8 is even
Test 2: Input: 7
Expected output: 7 is odd
Test 3: Input: 0
Expected output: 0 is even

## Sample Output
```text
Enter an integer: 7
7 is odd
```

## Output Screenshot
Save a screenshot of the actual program output here after running `program.py`. The text output above is illustrative, not a screenshot.

## Conclusion
The program uses the remainder after division by 2 to check whether a number is even or odd.
