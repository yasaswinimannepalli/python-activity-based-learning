# Case Study 8: Factorial of a Number

## Student Details
- **Name:** Mannepalli Yasaswini
- **Roll Number:** 26000946
- **Branch:** CSE, AIML
- **Section:** CSM2

## Problem Statement
Calculate the factorial of a non-negative integer using a loop.

## Objectives
Practice loops and accumulator variables.

## Assumptions
The input should be a non-negative integer; 0! equals 1.

## Algorithm
1. Start.
2. Read integer n.
3. If n is negative, display an error message.
4. Otherwise initialize factorial = 1 and multiply it by each integer from 1 to n.
5. Display the result and stop.

## Flowchart
```text
[START]
   |
[Read n]
   |
[n < 0?] --Yes--> [Display error]
   |
   No
   v
[factorial = 1; loop i = 1 to n]
   |
[Display factorial]
   |
 [STOP]
```

## Pseudocode
```text
BEGIN
  INPUT n
  IF n < 0 THEN PRINT error
  ELSE
    factorial ← 1
    FOR i FROM 1 TO n DO
      factorial ← factorial × i
    PRINT factorial
END
```

## Python Source Code
```python
n = int(input("Enter a non-negative integer: "))

if n < 0:
    print("Factorial is not defined for negative integers")
else:
    factorial = 1
    for i in range(1, n + 1):
        factorial *= i
    print("Factorial =", factorial)
```

## Test Cases
Test 1: Input: 5
Expected output: Factorial = 120
Test 2: Input: 0
Expected output: Factorial = 1
Test 3: Input: -2
Expected output: Error message for negative integer

## Sample Output
```text
Enter a non-negative integer: 5
Factorial = 120
```

## Output Screenshot
Save a screenshot of the actual program output here after running `program.py`. The text output above is illustrative, not a screenshot.

## Conclusion
The program uses a for loop to calculate the factorial of a non-negative integer.
