marks = []

for i in range(1, 4):
    mark = float(input(f"Enter marks for subject {i} (0-100): "))
    marks.append(mark)

total = sum(marks)
average = total / len(marks)

print("Total marks =", total)
print("Average marks =", average)
