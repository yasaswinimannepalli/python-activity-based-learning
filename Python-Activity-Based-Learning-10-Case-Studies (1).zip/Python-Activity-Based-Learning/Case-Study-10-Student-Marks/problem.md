# Case Study 10: Student Marks and Average

## Student Details
- **Name:** Mannepalli Yasaswini
- **Roll Number:** 26000946
- **Branch:** CSE, AIML
- **Section:** CSM2

## Problem Statement
Read marks for three subjects and calculate the total and average.

## Objectives
Practice lists, loops, sum(), and arithmetic.

## Assumptions
Marks are entered as numeric values between 0 and 100.

## Algorithm
1. Start.
2. Read marks for three subjects into a list.
3. Calculate total = sum of marks.
4. Calculate average = total / 3.
5. Display total and average.
6. Stop.

## Flowchart
```text
[START]
   |
[Read 3 subject marks]
   |
[Calculate total = sum(marks)]
   |
[average = total / 3]
   |
[Display total and average]
   |
 [STOP]
```

## Pseudocode
```text
BEGIN
  marks ← empty list
  REPEAT 3 TIMES
    INPUT mark
    APPEND mark TO marks
  total ← SUM(marks)
  average ← total / 3
  PRINT total, average
END
```

## Python Source Code
```python
marks = []

for i in range(1, 4):
    mark = float(input(f"Enter marks for subject {i} (0-100): "))
    marks.append(mark)

total = sum(marks)
average = total / len(marks)

print("Total marks =", total)
print("Average marks =", average)
```

## Test Cases
Test 1: Input: 80, 90, 70
Expected output: Total marks = 240.0; Average marks = 80.0
Test 2: Input: 100, 100, 90
Expected output: Total marks = 290.0; Average marks ≈ 96.67

## Sample Output
```text
Enter marks for subject 1 (0-100): 80
Enter marks for subject 2 (0-100): 90
Enter marks for subject 3 (0-100): 70
Total marks = 240.0
Average marks = 80.0
```

## Output Screenshot
Save a screenshot of the actual program output here after running `program.py`. The text output above is illustrative, not a screenshot.

## Conclusion
The program stores marks in a list and calculates their total and average.
