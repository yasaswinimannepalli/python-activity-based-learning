# Case Study 1: Student Details Display

## Student Details
- **Name:** Mannepalli Yasaswini
- **Roll Number:** 26000946
- **Branch:** CSE, AIML
- **Section:** CSM2

## Problem Statement
Write a Python program to display a student's name, branch, and semester.

## Objectives
Practice variables, strings, input(), and print().

## Assumptions
The student enters their name, branch, and semester.

## Algorithm
1. Start.
2. Read name, branch, and semester.
3. Display the entered details.
4. Stop.

## Flowchart
```text
[START]
   |
[Read name, branch, semester]
   |
[Display student details]
   |
 [STOP]
```

## Pseudocode
```text
BEGIN
  INPUT name, branch, semester
  PRINT name, branch, semester
END
```

## Python Source Code
```python
name = input("Enter student name: ")
branch = input("Enter branch: ")
semester = input("Enter semester: ")

print("\n--- Student Details ---")
print("Name:", name)
print("Branch:", branch)
print("Semester:", semester)
```

## Test Cases
Test 1: Input: Anu, CSE, 1
Expected output: Name: Anu; Branch: CSE; Semester: 1

## Sample Output
```text
Enter student name: Anu
Enter branch: CSE
Enter semester: 1

--- Student Details ---
Name: Anu
Branch: CSE
Semester: 1
```

## Output Screenshot
Save a screenshot of the actual program output here after running `program.py`. The text output above is illustrative, not a screenshot.

## Conclusion
This program demonstrates storing and displaying student information using variables.
