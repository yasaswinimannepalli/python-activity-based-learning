name = input("Enter student name: ")
branch = input("Enter branch: ")
semester = input("Enter semester: ")

print("\n--- Student Details ---")
print("Name:", name)
print("Branch:", branch)
print("Semester:", semester)
