# Case Study 9: Multiplication Table

## Student Details
- **Name:** Mannepalli Yasaswini
- **Roll Number:** 26000946
- **Branch:** CSE, AIML
- **Section:** CSM2

## Problem Statement
Display the multiplication table of a number from 1 to 10.

## Objectives
Use a for loop and multiplication.

## Assumptions
The user enters an integer.

## Algorithm
1. Start.
2. Read integer n.
3. Repeat i from 1 to 10.
4. Display n × i for each i.
5. Stop.

## Flowchart
```text
[START]
   |
[Read n]
   |
[Loop i from 1 through 10]
   |
[Print n × i]
   |
 [STOP]
```

## Pseudocode
```text
BEGIN
  INPUT n
  FOR i FROM 1 TO 10 DO
    PRINT n, "x", i, "=", n × i
END
```

## Python Source Code
```python
n = int(input("Enter a number: "))

for i in range(1, 11):
    print(n, "x", i, "=", n * i)
```

## Test Cases
Test 1: Input: 3
Expected output: First line: 3 x 1 = 3; last line: 3 x 10 = 30
Test 2: Input: 7
Expected output: First line: 7 x 1 = 7; last line: 7 x 10 = 70

## Sample Output
```text
Enter a number: 3
3 x 1 = 3
3 x 2 = 6
3 x 3 = 9
3 x 4 = 12
3 x 5 = 15
3 x 6 = 18
3 x 7 = 21
3 x 8 = 24
3 x 9 = 27
3 x 10 = 30
```

## Output Screenshot
Save a screenshot of the actual program output here after running `program.py`. The text output above is illustrative, not a screenshot.

## Conclusion
The program generates ten multiples of the given number using a loop.
