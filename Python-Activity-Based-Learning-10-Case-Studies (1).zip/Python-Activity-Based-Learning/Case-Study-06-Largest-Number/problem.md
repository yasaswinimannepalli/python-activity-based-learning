# Case Study 6: Largest of Two Numbers

## Student Details
- **Name:** Mannepalli Yasaswini
- **Roll Number:** 26000946
- **Branch:** CSE, AIML
- **Section:** CSM2

## Problem Statement
Read two numbers and display the larger number, or report if they are equal.

## Objectives
Use if, elif, and else statements to compare values.

## Assumptions
The user enters valid numbers.

## Algorithm
1. Start.
2. Read numbers a and b.
3. If a > b, display a.
4. Else if b > a, display b.
5. Otherwise display that both are equal.
6. Stop.

## Flowchart
```text
[START]
   |
[Read a and b]
   |
[a > b?] --Yes--> [Display a]
   |
   No
   v
[b > a?] --Yes--> [Display b]
   |
   No
   v
[Display both equal]
   |
 [STOP]
```

## Pseudocode
```text
BEGIN
  INPUT a, b
  IF a > b THEN PRINT a is larger
  ELSE IF b > a THEN PRINT b is larger
  ELSE PRINT both are equal
END
```

## Python Source Code
```python
a = float(input("Enter first number: "))
b = float(input("Enter second number: "))

if a > b:
    print("Largest number =", a)
elif b > a:
    print("Largest number =", b)
else:
    print("Both numbers are equal")
```

## Test Cases
Test 1: Input: 8, 3
Expected output: Largest number = 8.0
Test 2: Input: 4, 9
Expected output: Largest number = 9.0
Test 3: Input: 6, 6
Expected output: Both numbers are equal

## Sample Output
```text
Enter first number: 8
Enter second number: 3
Largest number = 8.0
```

## Output Screenshot
Save a screenshot of the actual program output here after running `program.py`. The text output above is illustrative, not a screenshot.

## Conclusion
The program uses conditional statements to identify the larger of two numbers.
