# Case Study 5: Simple Interest Calculation

## Student Details
- **Name:** Mannepalli Yasaswini
- **Roll Number:** 26000946
- **Branch:** CSE, AIML
- **Section:** CSM2

## Problem Statement
Calculate simple interest using principal, annual rate, and time.

## Objectives
Practice arithmetic expressions and numeric input conversion.

## Assumptions
Principal, annual rate, and time are non-negative; rate is an annual percentage.

## Algorithm
1. Start.
2. Read principal P, rate R, and time T.
3. Calculate SI = (P × R × T) / 100.
4. Display simple interest.
5. Stop.

## Flowchart
```text
[START]
   |
[Read P, R, T]
   |
[SI = P × R × T / 100]
   |
[Display SI]
   |
 [STOP]
```

## Pseudocode
```text
BEGIN
  INPUT P, R, T
  SI ← (P × R × T) / 100
  PRINT SI
END
```

## Python Source Code
```python
principal = float(input("Enter principal amount: "))
rate = float(input("Enter annual rate (%): "))
time = float(input("Enter time in years: "))

simple_interest = (principal * rate * time) / 100
print("Simple Interest =", simple_interest)
```

## Test Cases
Test 1: Input: 1000, 5, 2
Expected output: Simple Interest = 100.0
Test 2: Input: 5000, 4, 3
Expected output: Simple Interest = 600.0

## Sample Output
```text
Enter principal amount: 1000
Enter annual rate (%): 5
Enter time in years: 2
Simple Interest = 100.0
```

## Output Screenshot
Save a screenshot of the actual program output here after running `program.py`. The text output above is illustrative, not a screenshot.

## Conclusion
The program computes simple interest using SI = (P × R × T) / 100.
