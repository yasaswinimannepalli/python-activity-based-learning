# Python Activity-Based Learning

## Student Details
- **Name:** Mannepalli Yasaswini
- **Roll Number:** 26000946
- **Branch:** CSE, AIML
- **Section:** CSM2

## Selected Case Studies
1. Student Details Display
2. Sum and Product of Two Numbers
3. Celsius to Fahrenheit Conversion
4. Area and Perimeter of a Rectangle
5. Simple Interest Calculation
6. Largest of Two Numbers
7. Check Even or Odd
8. Factorial of a Number
9. Multiplication Table
10. Student Marks and Average

## Repository Contents
Each case-study folder contains:
- `problem.md` — documentation, objectives, assumptions, algorithm, flowchart, pseudocode, test cases, sample output, and conclusion
- `program.py` — executable Python source code
- `flowchart.txt` — text version of the flowchart
- `output.txt` — illustrative sample output

## How to Run
Use Python 3 and run a program from its folder:
```bash
python program.py
```

Note: The sample outputs are examples. Run each program yourself and save actual screenshots if your instructor requires output screenshots.
